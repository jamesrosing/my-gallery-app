export default {
    name: 'procedure',
    title: 'Procedure',
    type: 'document',
    fields: [
      {
        name: 'title',
        title: 'Title',
        type: 'string',
      },
    ],
  }
  