import procedure from './procedure'
import caseSchema from './case'

export default [procedure, caseSchema]
